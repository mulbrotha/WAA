/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleserver;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.net.ssl.SSLServerSocket;

/**
 *
 * @author csfaculty
 */
public class Server {
    
    private int port = 8181;
    private int backlog= 5;
    private String bindingAddress = "127.0.0.1";
    
    public void startup() {
        try {
            ServerSocket serverSocket = new ServerSocket(port, backlog, InetAddress.getByName(bindingAddress));
            System.out.println("Ready");
            Socket socket = serverSocket.accept();
            System.out.println("Accepted");
            InputStream inputStream = socket.getInputStream();
            OutputStream outputStream = socket.getOutputStream();
            int characterRead = 0;
            while (inputStream.available() != 0) {
                characterRead= inputStream.read();
                System.out.print((char) characterRead);
            }
            socket.close();
        } catch (UnknownHostException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
